def formula(l: float) -> float:
    r = l * l * l
    return r

def formula2(l: float, m: float) -> float:
    x = -4 * -4 * -4 * 8
    return x