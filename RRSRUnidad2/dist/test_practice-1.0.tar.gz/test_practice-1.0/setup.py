from setuptools import setup

setup(
    name='test_practice',
    version='1.0',
    description='The equations example the ',
    author='RRSR',
    author_email='ramiro.93148@gmail.com',
    url='github.com.mx',
    py_modules=['test_practice'],
)
